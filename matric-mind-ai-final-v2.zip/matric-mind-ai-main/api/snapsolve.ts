import { NextRequest } from "next/server";
import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const SUBJECT_PROMPTS: Record<string, string> = {
  mathematics: 'You are an expert Mathematics tutor specializing in algebra, calculus, geometry, and trigonometry.',
  mathematical_literacy: 'You are an expert Mathematical Literacy tutor focusing on practical math applications.',
  physical_sciences: 'You are an expert Physical Sciences tutor covering physics and chemistry concepts.',
  life_sciences: 'You are an expert Life Sciences tutor specializing in biology and life processes.',
  accounting: 'You are an expert Accounting tutor covering financial statements, bookkeeping, and analysis.',
  business_studies: 'You are an expert Business Studies tutor covering management and entrepreneurship.',
  economics: 'You are an expert Economics tutor covering micro and macroeconomics.',
  geography: 'You are an expert Geography tutor covering physical and human geography.',
  history: 'You are an expert History tutor covering South African and world history.',
  english_home_language: 'You are an expert English tutor covering literature, grammar, and writing.',
  english_first_additional: 'You are an expert English tutor for first additional language learners.',
  life_orientation: 'You are an expert Life Orientation tutor covering life skills and wellness.',
  information_technology: 'You are an expert IT tutor covering programming and systems.',
};

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { image, subject, context } = body;

    if (!image) {
      return new Response(JSON.stringify({ error: "Image is required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    if (!process.env.OPENAI_API_KEY) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured" }),
        { status: 503, headers: { "Content-Type": "application/json" } }
      );
    }

    const subjectPrompt = SUBJECT_PROMPTS[subject] || SUBJECT_PROMPTS.mathematics;

    const systemPrompt = `${subjectPrompt}

You are helping a South African Matric student solve a question from an image. Your task is to:

1. Identify the question from the image
2. Provide a clear, step-by-step solution
3. Explain the underlying concepts
4. Give helpful study tips

Always respond in this exact JSON format:
{
  "question": "The question as you understand it from the image",
  "steps": ["Step 1: ...", "Step 2: ..."],
  "answer": "The final answer",
  "explanation": "A brief explanation of the concepts used",
  "tips": ["Tip 1", "Tip 2", "Tip 3"]
}

Be encouraging and educational. Break down complex problems into simple steps.`;

    const response = await client.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: context
                ? `Please solve this question. Additional context: ${context}`
                : "Please solve this question and explain the solution step by step.",
            },
            {
              type: "image_url",
              image_url: {
                url: image, // Assumes base64 data URL
              },
            },
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 2000,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    const solution = JSON.parse(content);

    return new Response(JSON.stringify({ solution }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error: any) {
    console.error("SnapSolve Error:", error);
    return new Response(
      JSON.stringify({
        error: "Failed to process image",
        details: error.message,
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}
