export interface ConversationMessage {
  role: "user" | "assistant";
  content: string;
}

/**
 * Ask the AI tutor a question with subject context and conversation history.
 * 
 * @param message - The user's question or message
 * @param subject - The subject being tutored (e.g., "mathematics", "life_sciences")
 * @param conversationHistory - Previous messages in the conversation for context
 * @returns The AI tutor's response
 */
export const askAI = async (
  message: string,
  subject?: string,
  conversationHistory?: ConversationMessage[]
) => {
  try {
    const res = await fetch("/api/tutor", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message,
        subject,
        conversationHistory,
      }),
    });

    const data = await res.json();

    return data.reply || "⚠️ No response";
  } catch (error) {
    console.error("Frontend AI Error:", error);
    return "⚠️ AI connection failed";
  }
};

/**
 * Format conversation history for display in the UI.
 * Removes any sensitive data and ensures proper formatting.
 */
export const formatConversationHistory = (
  messages: ConversationMessage[]
): ConversationMessage[] => {
  return messages.map((msg) => ({
    role: msg.role,
    content: msg.content.trim(),
  }));
};

/**
 * Extract the last N messages from conversation history for context window.
 * Helps manage token limits by keeping only recent context.
 */
export const getRecentConversationContext = (
  messages: ConversationMessage[],
  maxMessages: number = 10
): ConversationMessage[] => {
  return messages.slice(-maxMessages);
};
