import { useState, useRef, useEffect, useCallback, memo } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { SUBJECT_LABELS, SUBJECT_ICONS, ALL_SUBJECTS } from '@/lib/subjects';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, Bot, User, Loader2, Sparkles, Plus, Paperclip, Mic, MicOff, 
  X, FileText, ChevronDown, Volume2, VolumeX, Minimize2, Maximize2,
  MessageCircle
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { askAI, getRecentConversationContext, type ConversationMessage } from '@/services/ai';
import type { Database } from '@/integrations/supabase/types';

type MatricSubject = Database['public']['Enums']['matric_subject'];

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

// Memoized message component for better performance
const ChatMessage = memo(({ msg }: { msg: Message }) => {
  const isUser = msg.role === 'user';
  
  return (
    <div className={`flex gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && (
        <div className="w-7 h-7 rounded-full gradient-gold flex items-center justify-center shrink-0">
          <Bot className="w-3.5 h-3.5 text-secondary-foreground" />
        </div>
      )}
      
      <div className={`max-w-[85%] ${isUser ? 'order-first' : ''}`}>
        <div className={`rounded-2xl px-3 py-2 text-sm ${
          isUser ? 'bg-primary text-primary-foreground' : 'bg-muted'
        }`}>
          {!isUser ? (
            <div className="prose prose-sm max-w-none dark:prose-invert prose-p:my-1.5 prose-headings:my-2 prose-ul:my-1.5 prose-ol:my-1.5 prose-li:my-0.5">
              <ReactMarkdown>{msg.content}</ReactMarkdown>
            </div>
          ) : (
            <p className="whitespace-pre-wrap">{msg.content}</p>
          )}
        </div>
      </div>
      
      {isUser && (
        <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center shrink-0">
          <User className="w-3.5 h-3.5 text-primary-foreground" />
        </div>
      )}
    </div>
  );
});
ChatMessage.displayName = 'ChatMessage';

export default function FloatingAITutor() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<MatricSubject | ''>('');
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [showScrollButton, setShowScrollButton] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll on new messages
  useEffect(() => {
    if (messages.length > 0) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages.length]);

  // Scroll detection
  useEffect(() => {
    const container = messagesContainerRef.current;
    if (!container) return;
    
    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      setShowScrollButton(scrollHeight - scrollTop - clientHeight > 80);
    };
    
    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, [isOpen]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 100) + 'px';
    }
  }, [inputValue]);

  // Text-to-speech for AI responses (only when enabled)
  useEffect(() => {
    if (isMuted || isLoading || messages.length === 0) return;
    
    const lastMessage = messages[messages.length - 1];
    if (lastMessage.role !== 'assistant') return;
    
    const text = lastMessage.content;
    if (!text) return;
    
    speechSynthesis.cancel();
    const cleanText = text
      .replace(/\*\*/g, '')
      .replace(/\*/g, '')
      .replace(/#+\s/g, '')
      .replace(/```[\s\S]*?```/g, '')
      .replace(/`[^`]+`/g, match => match.slice(1, -1))
      .substring(0, 300);
    
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.1;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    
    speechSynthesis.speak(utterance);
  }, [messages, isLoading, isMuted]);

  const stopSpeaking = useCallback(() => {
    speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const handleSubjectChange = useCallback((v: string) => {
    setSelectedSubject(v as MatricSubject);
    setMessages([]);
  }, []);

  const handleNewChat = useCallback(() => {
    setMessages([]);
    stopSpeaking();
  }, [stopSpeaking]);

  const handleSendMessage = useCallback(async () => {
    if (!inputValue.trim() || !selectedSubject || isLoading) return;

    const userText = inputValue.trim();
    
    // Add user message
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: userText,
    };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');

    setIsLoading(true);

    try {
      // Convert messages to conversation history format
      const conversationHistory: ConversationMessage[] = messages.map(msg => ({
        role: msg.role,
        content: msg.content,
      }));

      // Get recent context to avoid token limit issues
      const recentContext = getRecentConversationContext(conversationHistory, 8);

      // Call the intelligent AI service with subject and conversation history
      const reply = await askAI(userText, selectedSubject as string, recentContext);

      // Add AI response
      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: reply || '⚠️ AI failed to respond',
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMsg: Message = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: '⚠️ Connection failed. Please try again.',
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  }, [inputValue, selectedSubject, isLoading, messages]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  }, [handleSendMessage]);

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full gradient-gold shadow-lg flex items-center justify-center"
          >
            <MessageCircle className="w-6 h-6 text-secondary-foreground" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-48px)] bg-card border border-border rounded-2xl shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-3 py-2.5 border-b bg-card">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full gradient-gold flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-secondary-foreground" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold leading-tight">AI Tutor</h3>
                  {isSpeaking && (
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Volume2 className="w-2.5 h-2.5 animate-pulse" /> Speaking
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-0.5">
                <TooltipProvider delayDuration={300}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-7 w-7" 
                        onClick={() => { isMuted ? setIsMuted(false) : (stopSpeaking(), setIsMuted(true)); }}
                      >
                        {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">{isMuted ? 'Enable voice' : 'Mute'}</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleNewChat}>
                        <Plus className="w-3.5 h-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">New chat</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setIsMinimized(!isMinimized)}>
                        {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">{isMinimized ? 'Expand' : 'Minimize'}</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setIsOpen(false)}>
                  <X className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>

            {!isMinimized && (
              <>
                {/* Subject Selector */}
                <div className="px-3 py-2 border-b bg-muted/20">
                  <Select value={selectedSubject} onValueChange={handleSubjectChange}>
                    <SelectTrigger className="h-8 text-xs">
                      <SelectValue placeholder="Select a subject" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[280px]">
                      {ALL_SUBJECTS.map(s => (
                        <SelectItem key={s} value={s}>
                          <span className="flex items-center gap-2">
                            <span>{SUBJECT_ICONS[s]}</span>
                            <span>{SUBJECT_LABELS[s]}</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Messages */}
                <div 
                  ref={messagesContainerRef}
                  className="flex-1 overflow-y-auto px-3 py-3 space-y-3"
                >
                  {/* Empty State */}
                  {messages.length === 0 && (
                    <div className="h-full flex items-center justify-center py-8">
                      <div className="text-center px-4">
                        {selectedSubject ? (
                          <>
                            <div className="text-4xl mb-2">{SUBJECT_ICONS[selectedSubject]}</div>
                            <h4 className="font-semibold text-sm mb-1">{SUBJECT_LABELS[selectedSubject]}</h4>
                            <p className="text-xs text-muted-foreground mb-3">
                              Your intelligent tutor is ready to help
                            </p>
                            <div className="flex flex-wrap gap-1.5 justify-center">
                              {['Explain this', 'Help me solve', 'Practice questions'].map((s, i) => (
                                <Button
                                  key={i}
                                  variant="outline"
                                  size="sm"
                                  className="text-[10px] h-6 px-2"
                                  onClick={() => setInputValue(s)}
                                >
                                  {s}
                                </Button>
                              ))}
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="w-12 h-12 rounded-full gradient-navy mx-auto mb-2 flex items-center justify-center">
                              <Bot className="w-6 h-6 text-white" />
                            </div>
                            <h4 className="font-semibold text-sm mb-1">Choose a Subject</h4>
                            <p className="text-xs text-muted-foreground">
                              Select above to start
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Messages List */}
                  {messages.map((msg) => (
                    <ChatMessage key={msg.id} msg={msg} />
                  ))}

                  {/* Loading indicator */}
                  {isLoading && (
                    <div className="flex gap-2">
                      <div className="w-7 h-7 rounded-full gradient-gold flex items-center justify-center shrink-0">
                        <Bot className="w-3.5 h-3.5 text-secondary-foreground" />
                      </div>
                      <div className="bg-muted rounded-2xl px-3 py-2 flex items-center gap-1.5">
                        <span className="flex gap-0.5">
                          <span className="w-1.5 h-1.5 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-1.5 h-1.5 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-1.5 h-1.5 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        </span>
                      </div>
                    </div>
                  )}

                  <div ref={messagesEndRef} />
                </div>

                {/* Scroll Button */}
                {showScrollButton && (
                  <Button
                    variant="secondary"
                    size="icon"
                    className="absolute bottom-28 right-3 h-6 w-6 rounded-full shadow"
                    onClick={scrollToBottom}
                  >
                    <ChevronDown className="w-3 h-3" />
                  </Button>
                )}

                {/* Input Area */}
                <div className="border-t bg-card p-2.5">
                  <div className="flex items-end gap-1.5">
                    {/* Input */}
                    <Textarea
                      ref={textareaRef}
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder={selectedSubject ? 'Ask anything...' : 'Select a subject'}
                      disabled={!selectedSubject || isLoading}
                      className="flex-1 min-h-[36px] max-h-[100px] resize-none border-0 focus-visible:ring-0 bg-muted/50 rounded-xl text-sm py-2 px-3"
                      rows={1}
                    />

                    {/* Send */}
                    <Button
                      size="icon"
                      className="shrink-0 h-8 w-8 rounded-full"
                      onClick={handleSendMessage}
                      disabled={!selectedSubject || !inputValue.trim() || isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Send className="w-3.5 h-3.5" />
                      )}
                    </Button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
