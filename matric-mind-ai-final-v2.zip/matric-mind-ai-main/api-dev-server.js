/**
 * Local API Development Server
 * ==============================
 * This server mirrors the Vercel serverless functions locally so that
 * the Vite dev server can proxy /api/* requests to it.
 *
 * Usage:
 *   1. Make sure you have set OPENAI_API_KEY in your .env file.
 *   2. In one terminal: node api-dev-server.js
 *   3. In another terminal: npm run dev
 *
 * The Vite dev server (port 8080) will proxy /api/* to this server (port 3002).
 */

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors());
app.use(express.json({ limit: '20mb' }));

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// ─── Subject system prompts ───────────────────────────────────────────────────
const SUBJECT_PROMPTS = {
  mathematics: `You are an expert South African Matric Mathematics tutor. Explain clearly, step-by-step.`,
  mathematical_literacy: `You are an expert South African Matric Mathematical Literacy tutor. Focus on practical application.`,
  physical_sciences: `You are an expert South African Matric Physical Sciences tutor. Explain physics and chemistry concepts clearly.`,
  life_sciences: `You are an expert South African Matric Life Sciences tutor. Explain biological processes simply.`,
  accounting: `You are an expert South African Matric Accounting tutor. Explain debits, credits, and financial statements.`,
  business_studies: `You are an expert South African Matric Business Studies tutor. Use real business examples.`,
  economics: `You are an expert South African Matric Economics tutor. Connect to the SA economic context.`,
  geography: `You are an expert South African Matric Geography tutor. Explain spatial patterns and processes.`,
  history: `You are an expert South African Matric History tutor. Provide historical context and analysis.`,
  english_home_language: `You are an expert South African Matric English tutor. Help with literature and essay writing.`,
  english_first_additional: `You are an expert South African Matric English FAL tutor. Focus on comprehension and grammar.`,
  life_orientation: `You are an expert South African Matric Life Orientation tutor. Support personal development.`,
  information_technology: `You are an expert South African Matric IT tutor. Help with programming and algorithms.`,
};
const DEFAULT_PROMPT = `You are a smart South African matric tutor. Explain clearly, step-by-step.`;

// ─── POST /api/tutor ──────────────────────────────────────────────────────────
app.post('/api/tutor', async (req, res) => {
  try {
    const { message, subject, conversationHistory } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'No message provided' });
    }

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({
        error: 'OPENAI_API_KEY is not set. Please add it to your .env file.',
      });
    }

    const subjectPrompt = subject ? SUBJECT_PROMPTS[subject] || DEFAULT_PROMPT : DEFAULT_PROMPT;

    // Build messages array with conversation history for context
    const messages = [];
    
    // Add previous conversation turns if provided (for memory)
    if (conversationHistory && Array.isArray(conversationHistory)) {
      conversationHistory.forEach((msg) => {
        messages.push({
          role: msg.role === "user" ? "user" : "assistant",
          content: msg.content,
        });
      });
    }
    
    // Add current message
    messages.push({
      role: "user",
      content: message,
    });

    const completion = await client.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: subjectPrompt,
        },
        ...messages,
      ],
      max_tokens: 600,
      temperature: 0.7,
    });

    const reply =
      completion.choices?.[0]?.message?.content ||
      "⚠️ AI returned empty response";

    res.json({ reply });
  } catch (err) {
    console.error('AI Tutor error:', err);
    res.status(500).json({ error: 'Failed to generate response', details: String(err) });
  }
});

// ─── POST /api/ai (legacy mock endpoint) ─────────────────────────────────────
app.post('/api/ai', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Prompt is required and must be a string' });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({ error: 'OPENAI_API_KEY is not set.' });
  }

  try {
    const completion = await client.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 300,
    });

    const reply = completion.choices?.[0]?.message?.content || "⚠️ AI failed";
    res.json({ reply });
  } catch (err) {
    console.error('AI error:', err);
    res.status(500).json({ error: 'AI failed' });
  }
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = 3002;
app.listen(PORT, () => {
  console.log(`\n✅ Local API dev server running at http://localhost:${PORT}`);
  console.log(`   OPENAI_API_KEY: ${process.env.OPENAI_API_KEY ? '✓ set' : '✗ MISSING — add it to .env!'}`);
  console.log(`\n   Now run "npm run dev" in another terminal.\n`);
});
