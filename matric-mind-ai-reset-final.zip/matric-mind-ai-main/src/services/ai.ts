/**
 * SINGLE AI GATEWAY
 * ==================
 * This is the ONLY entry point for all AI calls in the entire app.
 * No other components should call /api/* directly.
 * 
 * Contract:
 * - Input: { message: string }
 * - Output: string (never empty, never undefined)
 * - Errors: Always return a safe fallback message
 */

export const askAI = async (message: string) => {
  try {
    // Validate input
    if (!message || typeof message !== "string" || !message.trim()) {
      return "⚠️ Please provide a valid message.";
    }

    const res = await fetch("/api/tutor", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message: message.trim() }),
    });

    // Check response status
    if (!res.ok) {
      console.error(`[askAI] Server error: ${res.status}`);
      return "⚠️ Server error. Please try again.";
    }

    const data = await res.json();

    // 🔒 HARD VALIDATION: Ensure reply exists and is a non-empty string
    if (!data || typeof data.reply !== "string" || !data.reply.trim()) {
      console.error("[askAI] Invalid response structure:", data);
      return "⚠️ AI returned no usable response.";
    }

    return data.reply.trim();
  } catch (error) {
    console.error("[askAI] Error:", error);
    return "⚠️ AI is currently unavailable. Please try again.";
  }
};
