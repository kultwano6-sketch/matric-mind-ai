import { useState, useRef, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { SUBJECT_LABELS, SUBJECT_ICONS, ALL_SUBJECTS } from '@/lib/subjects';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Loader2, Sparkles, Plus, X, ChevronDown, Trash2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { askAI } from '@/services/ai';
import type { Database } from '@/integrations/supabase/types';

type MatricSubject = Database['public']['Enums']['matric_subject'];

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export default function Tutor() {
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const [selectedSubject, setSelectedSubject] = useState<MatricSubject | ''>(
    (searchParams.get('subject') as MatricSubject) || ''
  );
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll
  useEffect(() => {
    if (messages.length > 0) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages.length]);

  // Scroll detection
  useEffect(() => {
    const container = messagesContainerRef.current;
    if (!container) return;
    
    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      setShowScrollButton(scrollHeight - scrollTop - clientHeight > 100);
    };
    
    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 140) + 'px';
    }
  }, [inputValue]);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const handleSubjectChange = useCallback((v: string) => {
    setSelectedSubject(v as MatricSubject);
    setMessages([]);
  }, []);

  const handleNewChat = useCallback(() => {
    setMessages([]);
  }, []);

  const handleClearHistory = useCallback(() => {
    setMessages([]);
  }, []);

  const handleSendMessage = useCallback(async () => {
    if (!inputValue.trim() || !selectedSubject || isLoading) return;

    const userText = inputValue.trim();
    
    // STEP 4: Add user message IMMEDIATELY using prev callback
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: userText,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');

    setIsLoading(true);

    try {
      // Call the single AI gateway
      const reply = await askAI(userText);

      // STEP 5: Hard failsafe - ensure reply is never empty
      const safeReply = reply || "⚠️ Empty response";

      // Add AI response using prev callback
      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: safeReply,
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (error) {
      console.error('Error sending message:', error);
      // Hard failsafe - always show error message
      const errorMsg: Message = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: '⚠️ Connection failed. Please try again.',
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  }, [inputValue, selectedSubject, isLoading]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  }, [handleSendMessage]);

  return (
    <DashboardLayout>
      <div className="h-[calc(100vh-8rem)] flex flex-col">
        {/* Messages Area */}
        <div ref={messagesContainerRef} className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto px-4 py-6">
            {/* Empty State */}
            <AnimatePresence mode="wait">
              {messages.length === 0 && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="min-h-[55vh] flex items-center justify-center"
                >
                  <div className="text-center max-w-lg">
                    {selectedSubject ? (
                      <>
                        <motion.div 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: 'spring', delay: 0.1 }}
                          className="text-6xl mb-4"
                        >
                          {SUBJECT_ICONS[selectedSubject]}
                        </motion.div>
                        <h2 className="text-2xl font-bold mb-2">
                          {SUBJECT_LABELS[selectedSubject]}
                        </h2>
                        <p className="text-muted-foreground mb-6">
                          Your AI tutor is ready to help you learn
                        </p>
                      </>
                    ) : (
                      <>
                        <motion.div 
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: 'spring', delay: 0.1 }}
                          className="w-20 h-20 rounded-2xl bg-primary mx-auto mb-5 flex items-center justify-center"
                        >
                          <Sparkles className="w-10 h-10 text-white" />
                        </motion.div>
                        <h2 className="text-2xl font-bold mb-2">
                          Welcome to Your AI Tutor
                        </h2>
                        <p className="text-muted-foreground mb-6">
                          Select a subject to get started
                        </p>
                      </>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Messages */}
            <div className="space-y-5">
              {messages.map((msg) => (
                <motion.div 
                  key={msg.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.role !== 'user' && (
                    <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                  )}
                  
                  <div className={`max-w-[75%] ${msg.role === 'user' ? 'order-first' : ''}`}>
                    <div className={`rounded-2xl px-4 py-3 ${
                      msg.role === 'user' ? 'bg-primary text-white' : 'bg-muted'
                    }`}>
                      {msg.role !== 'user' ? (
                        <div className="prose prose-sm max-w-none dark:prose-invert">
                          <ReactMarkdown>
                            {msg.content || "⚠️ Empty response"}
                          </ReactMarkdown>
                        </div>
                      ) : (
                        <p className="text-sm whitespace-pre-wrap">
                          {msg.content || "⚠️ Empty message"}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  {msg.role === 'user' && (
                    <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-4 h-4 text-white" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>

            {/* STEP 6: Loading indicator */}
            {isLoading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.15 }}
                className="flex gap-3 mt-5"
              >
                <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-muted rounded-2xl px-4 py-3 flex items-center gap-1.5">
                  <span className="flex gap-1">
                    <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </span>
                  <span className="text-sm text-muted-foreground ml-2">🤖 Thinking...</span>
                </div>
              </motion.div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Scroll button */}
        <AnimatePresence>
          {showScrollButton && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute bottom-36 left-1/2 -translate-x-1/2"
            >
              <Button
                variant="secondary"
                size="sm"
                className="rounded-full shadow-lg gap-1.5"
                onClick={scrollToBottom}
              >
                <ChevronDown className="w-4 h-4" />
                Scroll down
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Input Bar */}
        <div className="sticky bottom-0 bg-gradient-to-t from-background via-background to-transparent pt-4 pb-4 px-4">
          <div className="max-w-3xl mx-auto">
            {/* Controls */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Select value={selectedSubject} onValueChange={handleSubjectChange}>
                  <SelectTrigger className="w-[180px] h-8 text-xs border-dashed">
                    <SelectValue placeholder="Choose subject..." />
                  </SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    {ALL_SUBJECTS.map(s => (
                      <SelectItem key={s} value={s}>
                        <span className="flex items-center gap-2">
                          <span>{SUBJECT_ICONS[s]}</span>
                          <span>{SUBJECT_LABELS[s]}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {selectedSubject && messages.length > 0 && (
                  <>
                    <Button variant="ghost" size="sm" className="h-8 text-xs gap-1" onClick={handleNewChat}>
                      <Plus className="w-3 h-3" />
                      New
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-8 text-xs gap-1 text-destructive hover:text-destructive" 
                      onClick={handleClearHistory}
                    >
                      <Trash2 className="w-3 h-3" />
                      Clear
                    </Button>
                  </>
                )}
              </div>
            </div>
            
            {/* Input Card */}
            <div className="rounded-2xl border-2 bg-card shadow-lg overflow-hidden">
              <div className="px-3 pt-3 pb-3 flex items-end gap-2">
                {/* Input */}
                <Textarea
                  ref={textareaRef}
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={selectedSubject ? 'Ask your tutor anything...' : 'Select a subject first'}
                  disabled={!selectedSubject || isLoading}
                  className="flex-1 min-h-[40px] max-h-[120px] resize-none border-0 focus-visible:ring-0 bg-transparent text-sm py-2 px-0"
                  rows={1}
                />

                {/* Send Button */}
                <Button
                  size="icon"
                  className="shrink-0 h-8 w-8 rounded-full"
                  onClick={handleSendMessage}
                  disabled={!selectedSubject || !inputValue.trim() || isLoading}
                >
                  {isLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
