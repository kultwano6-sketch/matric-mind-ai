import { NextRequest } from "next/server";
import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(req: NextRequest) {
  try {
    // STEP 3: HARD INPUT VALIDATION
    const body = await req.json();
    const { message } = body;

    if (!message || typeof message !== "string") {
      return new Response(
        JSON.stringify({ reply: "Invalid input" }),
        { headers: { "Content-Type": "application/json" }, status: 400 }
      );
    }

    if (!process.env.OPENAI_API_KEY) {
      return new Response(
        JSON.stringify({ reply: "⚠️ AI service not configured" }),
        { headers: { "Content-Type": "application/json" }, status: 503 }
      );
    }

    const completion = await client.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a helpful South African Matric tutor. Provide clear, concise explanations. 
Always be encouraging and supportive. If you don't know something, say so honestly.
Keep responses focused and practical.`,
        },
        {
          role: "user",
          content: message,
        },
      ],
      max_tokens: 600,
      temperature: 0.7,
    });

    // 🔒 SAFE RESPONSE: Hard validation with fallback
    const reply =
      completion.choices?.[0]?.message?.content?.trim() ||
      "⚠️ AI could not generate a response.";

    return new Response(JSON.stringify({ reply }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error: any) {
    console.error("[api/tutor] Error:", error);

    return new Response(
      JSON.stringify({
        reply: "⚠️ AI failed. Check API key or try again.",
      }),
      { headers: { "Content-Type": "application/json" }, status: 500 }
    );
  }
}
